#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#define BUFFER_SIZE 10
#define CONSUMER 5
#define DATA 20
#define PRODUCER 5
sem_t mutex, full, empty;
int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;
void *producer_func(void *arguAddr) {
    int id = *(int*)arguAddr; 
    for (int i = 0; i < 4; i++) {
        int item = (id * 4) + i; 

        sem_wait(&empty); 
        sem_wait(&mutex); 

        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE; 
        printf("Producer %d wrote %d.\n", id, item);
        fflush(stdout);

        sem_post(&mutex); 
        sem_post(&full); 
    }
    pthread_exit(NULL);
}
void *consumer_func(void *arguAddr) {
    int id = *(int*)arguAddr; 
    for (int i = 0; i < 4; i++) {
        sem_wait(&full);  
        sem_wait(&mutex); 

        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE; 
        printf("Consumer %d got %d.\n", id, item);
        fflush(stdout);

        sem_post(&mutex); 
        sem_post(&empty); 
    }
    pthread_exit(NULL);
}
int main() {
    if (sem_init(&mutex, 0, 1) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    if (sem_init(&full, 0, 0) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    if (sem_init(&empty, 0, BUFFER_SIZE) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    pthread_t p[PRODUCER];
    int producer_ids[PRODUCER];
    for (int i = 0; i < PRODUCER; i++) {
        producer_ids[i] = i;
        pthread_create(&p[i], NULL, producer_func, &producer_ids[i]);
    }
    pthread_t c[CONSUMER];
    int consumer_ids[CONSUMER];
    for (int i = 0; i < CONSUMER; i++) {
        consumer_ids[i] = i;
        pthread_create(&c[i], NULL, consumer_func, &consumer_ids[i]);
    }
    for (int i = 0; i < PRODUCER; i++) {
        pthread_join(p[i], NULL);
    }
    for (int i = 0; i < CONSUMER; i++) {
        pthread_join(c[i], NULL);
    }
    sem_destroy(&mutex);
    sem_destroy(&full);
    sem_destroy(&empty);
    return 0;
}