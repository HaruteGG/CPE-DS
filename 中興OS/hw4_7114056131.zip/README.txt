OS Homework 4
學號：7114056131
姓名：張德望
開發環境：Ubuntu 20.04.3
如何編譯=========================================================================================
Basic
gcc hw4_7114056131_basic.c -o basic

Advanced
gcc hw4_7114056131_advanced.c -o advanced

執行=========================================================================================

./basic
程式會將 Producer 與 Consumer 的執行過程印在終端機

./advanced
程式執行時會自動建立 `out` 資料夾。
執行結束後會產出：
1. out資料夾：內含 10000 個 .txt 檔案 (檔名為數據, 內容為 Consumer ID)
2. result.txt：統整每個 Consumer 讀取了哪些資料
3. terminal顯示：每個 Thread 的 Waiting Time, Burst Time 與 Turnaround Timeu，以及執行過程。

程式功能說明=========================================================================================
Basic:
使用 Semaphores (Mutex Lock) 保護 Critical Section。
使用 Semaphores (empty, full) 控制 Buffer 的生產與消費同步。

Advanced:
擴充資料量至 10,000 筆。
計算並輸出各thread的時間統計 (使用 gettimeofday)。
實作檔案 I/O 操作 (mkdir, fopen, fprintf)。