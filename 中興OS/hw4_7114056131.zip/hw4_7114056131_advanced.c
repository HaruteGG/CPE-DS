#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/stat.h>  
#include <sys/types.h>
#include <sys/time.h>
#define BUFFER_SIZE 10
#define CONSUMER 5
#define DATA 10000
#define PRODUCER 5
#define PRODUCER_ITEMS (DATA / 5)
#define CONSUMER_ITEMS (DATA / 5)
sem_t mutex, full, empty;
int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;
int consumer_log[DATA];
void *producer_func(void *arguAddr) {
    int id = *(int*)arguAddr; 
    struct timeval start, end;
    double total_wait = 0, total_burst = 0;
    for (int i = 0; i < PRODUCER_ITEMS; i++) {
        int item = (id * PRODUCER_ITEMS) + i; 
        gettimeofday(&start, NULL);
        sem_wait(&empty); 
        sem_wait(&mutex); 
        gettimeofday(&end, NULL);
        long seconds = end.tv_sec - start.tv_sec;
        long micros = end.tv_usec - start.tv_usec;
        total_wait += seconds + micros*1e-6;
        gettimeofday(&start, NULL);
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE; 
        printf("Producer %d wrote %d.\n", id, item);
        fflush(stdout);
        sem_post(&mutex); 
        sem_post(&full);  
        gettimeofday(&end, NULL);
        seconds = end.tv_sec - start.tv_sec;
        micros = end.tv_usec - start.tv_usec;
        total_burst += seconds + micros*1e-6;
    }
    printf("producer %d: waiting time=%.4f s, burst time=%.4f s, turnaround time=%.4f s\n", id, total_wait, total_burst, total_wait + total_burst);
    pthread_exit(NULL);
}
void *consumer_func(void *arguAddr) {
    int id = *(int*)arguAddr; 
    struct timeval start, end;
    double total_wait = 0, total_burst = 0;
    for (int i = 0; i < CONSUMER_ITEMS; i++) {
        gettimeofday(&start, NULL);
        sem_wait(&full);  
        sem_wait(&mutex); 
        gettimeofday(&end, NULL);
        long seconds = end.tv_sec - start.tv_sec;
        long micros = end.tv_usec - start.tv_usec;
        total_wait += seconds + micros*1e-6;
        gettimeofday(&start, NULL);
        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE; 
        printf("Consumer %d got %d.\n", id, item);
        fflush(stdout);
        sem_post(&mutex); 
        sem_post(&empty);
        consumer_log[item] = id; 
        char filename[50];
        sprintf(filename, "out/%d.txt", item); 
        FILE *fp = fopen(filename, "w");
        if (fp) {
            fprintf(fp, "%d", id); 
            fclose(fp);
        }
        gettimeofday(&end, NULL);
        seconds = end.tv_sec - start.tv_sec;
        micros = end.tv_usec - start.tv_usec;
        total_burst += seconds + micros*1e-6;
    }
    printf("consumer %d: waiting time=%.4f s, burst time=%.4f s, turnaround time=%.4f s\n", id, total_wait, total_burst, total_wait + total_burst);
    pthread_exit(NULL);
}
int main() {
    if (sem_init(&mutex, 0, 1) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    if (sem_init(&full, 0, 0) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    if (sem_init(&empty, 0, BUFFER_SIZE) != 0) {
        perror("Failed to initialize semaphore. \n");
        return 1;
    }
    struct stat st = {0};
    if (stat("out", &st) == -1) {
        mkdir("out", 0777);
    }
    pthread_t p[PRODUCER];
    int producer_ids[PRODUCER];
    for (int i = 0; i < PRODUCER; i++) {
        producer_ids[i] = i;
        pthread_create(&p[i], NULL, producer_func, &producer_ids[i]);
    }
    pthread_t c[CONSUMER];
    int consumer_ids[CONSUMER];
    for (int i = 0; i < CONSUMER; i++) {
        consumer_ids[i] = i;
        pthread_create(&c[i], NULL, consumer_func, &consumer_ids[i]);
    }
    for (int i = 0; i < PRODUCER; i++) {
        pthread_join(p[i], NULL);
    }
    for (int i = 0; i < CONSUMER; i++) {
        pthread_join(c[i], NULL);
    }
    sem_destroy(&mutex);
    sem_destroy(&full);
    sem_destroy(&empty);
    FILE *fp_res = fopen("result.txt", "w");
    for (int i = 0; i < DATA; i++) {
        fprintf(fp_res, "Consumer %d: %d\n", consumer_log[i], i);
    }
    fclose(fp_res);
    return 0;
}